read the file(stock_collector read from web) parse and write to DB

cmd:
  php exe.php stockinfo|structinfo|historyprice|getstockno