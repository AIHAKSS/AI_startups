get the data from web, then write the raw data to file

cmd:
  php exe.php stocklist|stockstructinfo|historyprice